# -*- coding: utf-8 -*-
"""
Created on Fri Dec  1 15:49:28 2023

@author: lsd_u
"""
import matplotlib.pyplot as plt
import numpy as np

plt.figure(figsize=(8, 6))
for i in range(10):
    data = np.loadtxt (str(i+1)+'.dat',skiprows=1)
    voltages = data[:,0]
    currents = data[:,1]
    plt.plot(voltages, currents, marker='o', linestyle='-')
plt.title('Curva I-V')
plt.xlabel('V (V)')
plt.ylabel('I (A)')
plt.grid(True)
plt.show()
